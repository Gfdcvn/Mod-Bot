const { Message, MessageEmbed } = require("discord.js");
const Client = require("../src/client");
module.exports = {
  name: "apply",
  /**
   *
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {},
};
