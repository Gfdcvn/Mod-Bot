const { token, mongourl } = require("./Secure/tokens");

exports.token = token;
exports.version = "1.0";
exports.apiurl = "ram.gamearoo.top:3001";
exports.mongourl = mongourl;
exports.prefix = "-";
