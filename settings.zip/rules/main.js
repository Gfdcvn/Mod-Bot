const { one } = require("./1");
const { two } = require("./2");
const { three } = require("./3");
const { r4 } = require("./4");
const { r5 } = require("./5");
const { r6 } = require("./6");
const { r7 } = require("./7");
const { r8 } = require("./8");

module.exports = { one, two, three, r4, r5, r6, r7, r8 };
