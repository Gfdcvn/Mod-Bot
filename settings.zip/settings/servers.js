exports.mainserver = "605900262581993472";
exports.staffserver = "777437674708795392";
