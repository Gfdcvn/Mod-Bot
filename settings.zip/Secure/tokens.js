exports.token = "Nzk5MTYzNjk5MTcyMzQzODM5.X__lMQ.GLfK0Iqxfpli9cHEJuZEyh2suVU";
exports.mongourl =
  "mongodb://bot:445pzf0t1xma29i3sieiipplvlvwtud7@45.43.13.41:27017/mod?authSource=admin";
